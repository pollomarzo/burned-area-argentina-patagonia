### Supplementary figures legends

SF A) Burned area values histogram: Displays the distribution of computed burned area values (in km^2^) per pixel in AAPF from 2001 to 2020. This chart shows that most of the fire events detected as burned area were less than 10 km^2^ in size.
SF B) Monthly-grouped bar chart for total burned area from 2001 to 2020 (in km^2^): The bar chart shows that most of the study area was affected by fires from December to March. This validates the fire season range observed in previous studies in the area, indicating its occurrence from October to March (Mariani et al, 2018 & Kitzberger et al, 2022).
SF C) Time series bar chart: Displays the monthly total burned area in km^2^ for the subregion between latitudes -42.0&deg; and -42.5&deg; during 2001-2020. The impacts of fire events during 2015 have turned this area into one of the most affected during the whole series. 
SF D) Total annual precipitation variability by latitude: This chart shows the total annual averaged precipitation during 1981-2020 from ERA5 reanalysis. Each bar corresponds to a latitude within the AAPF.
