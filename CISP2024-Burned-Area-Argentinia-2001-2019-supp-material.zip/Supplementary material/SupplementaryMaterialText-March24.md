## Supplementary material

### Burned Area data processing methodology

Burned area data was obtained from MODIS Fire_cci version 5.1 product which comprises maps of monthly global burned area in a 0.25&deg; regular grid developed for research use. This product covers the period 2001-2020, and complements previous burned area products developed by the Fire CCI project (Pettinari et al., 2021). 

The dataset was clipped according to the AAPF area using the Argentinian Forestry Regions vector layer provided by the Argentinian Ministry of the Environment and Sustainable Development (MAyDS, 2014). Then, small fire events were masked out according to Mariani (2018) using the threshold 0.05336 km^2^ (5.3364 ha), which is the minimum value detected and the most frequent one in the dataset (supplementary figure A). The resulting dataset was used to obtain a grid with the total burned area for each complete fire season between 2001 and 2020. A fire season was defined from October to March, leaving 19 complete seasons to be analyzed (Mariani et al, 2018 & Kitzberger et al, 2022) (supplementary figure B). For example, the 2004 fire season extends between October 2004 to March 2005.

Total burned area was grouped by fire season for the whole study period. Then, the total burned area was summed along the x-axis (longitude) to retrieve the total burned area in each latitude. Finally, the total counts of active seasons for each latitude were calculated, computing 1 in each season if the total burned area in that latitude was more than zero. These results are shown in a horizontal barplot (figure C), in which the bars' length represents the active season counts, and the bars' colors represent the total burned area in km^2^ by latitude.

### Reanalysis data processing methodology

ERA5 monthly averaged reanalysis data was used to perform total annual precipitation and orography assessment in the AAPF region. The reanalysis data was obtained in a 0.25&deg; regular grid from [Copernicus Climate Change Service (C3S) Climate Data Store platform](https://cds.climate.copernicus.eu/cdsapp#!/dataset/reanalysis-era5-single-levels-monthly-means?tab=form).

The orography assessment was performed with the ERA5 Geopotential variable, with instructions provided in the metadata. The calculation involved a division by the Earth's gravitational acceleration (9.80665 ms^-2^) in order to compute the surface geopotential height (i.e. orography). The result shows the orography value in meters for each grid point (figure B). 

The precipitation assessment was performed with the ERA5 daily Total Precipitation variable for the 1940-2023 period. This dataset was first clipped using the vector layer for the AAPF region (MAyDS, 2014), then filtered  by time for the years between 1981-2020. The gridded dataset was averaged pixel by pixel to get the total annual precipitation. Finally, the mean value along the x-axis (longitude) was computed, to show the latitudinal variability. Results are shown in a horizontal bar chart, where each bar length represents the total annual precipitation by latitude averaged during 1981-2020 (supplementary figure D). 

### Land cover data processing methodology

The land cover assessment was performed with the Copernicus Global Land Service Dynamic Land Cover map at 100 m resolution (CGLS-LC100) (Buchhorn et al, 2020). The layers with discrete land cover types were retrieved via Google Earth Engine platform. Then, the clipping was done with the AAPF vector layer, including a buffer zone Finally, a comprehensive map was generated, overlaying all these layers using the QGIS free software. The result enhances the understanding of the different types of land covers and land uses within the AAPF region (figure A).